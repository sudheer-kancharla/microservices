package com.sms.greetingService.controller;

import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sms.greetingService.model.Message;
import com.sms.greetingService.model.MessageResponse;
import com.sms.greetingService.service.GreetingService;

@RestController
public class GreetingsController {

	@Autowired
	private GreetingService greetingService;
	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Autowired
	private Queue queue;

	@GetMapping(path="/send")
	public String send() {
		return "test-send-call";
	}

	@PostMapping(path="/send", consumes = "application/json")
	public ResponseEntity<String> send(@RequestBody Message message) {
		jmsTemplate.convertAndSend(queue, message);
		return new ResponseEntity<String>(message.getMessage(), HttpStatus.OK);
	}

	@GetMapping(path="/status", consumes = "application/json")
	public MessageResponse getStatus(@PathVariable String mobileNumber) {

		return greetingService.getStatus(mobileNumber);
	}
}
