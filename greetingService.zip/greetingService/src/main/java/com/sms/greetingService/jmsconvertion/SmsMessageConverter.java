package com.sms.greetingService.jmsconvertion;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class SmsMessageConverter implements MessageConverter {

	private static final Logger LOGGER = LoggerFactory.getLogger(SmsMessageConverter.class);
	ObjectMapper mapper;

	public SmsMessageConverter() {
		mapper = new ObjectMapper();
	}

	@Override
	public Message toMessage(Object object, Session session) throws JMSException, MessageConversionException {
		com.sms.greetingService.model.Message msg = (com.sms.greetingService.model.Message) object;
		String payload = null;
		try {
			payload = mapper.writeValueAsString(msg);
		} catch (JsonProcessingException jpeEx) {
			LOGGER.error("error occured while converting jms msg : " + jpeEx);
		}
		TextMessage message = session.createTextMessage(payload);
		message.setText(payload);
		return message;
	}

	@Override
	public Object fromMessage(Message message) throws JMSException, MessageConversionException {
		TextMessage textMsg = (TextMessage) message;
		String payload = textMsg.getText();

		com.sms.greetingService.model.Message msg = null;
		try {
			msg = mapper.readValue(payload, com.sms.greetingService.model.Message.class);
		} catch (Exception ex) {
			LOGGER.error("error occure while converting message from jmsObject : " + ex);
		}
		return msg;
	}

}
