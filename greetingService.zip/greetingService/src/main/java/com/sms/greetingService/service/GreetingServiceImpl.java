package com.sms.greetingService.service;

import org.springframework.stereotype.Service;

import com.sms.greetingService.model.MessageResponse;

@Service
public class GreetingServiceImpl implements GreetingService {

	@Override
	public MessageResponse getStatus(String mobileNumber) {
		return null;
	}

}
