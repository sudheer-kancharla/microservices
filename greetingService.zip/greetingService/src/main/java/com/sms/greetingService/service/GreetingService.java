package com.sms.greetingService.service;

import com.sms.greetingService.model.MessageResponse;

public interface GreetingService {
	public MessageResponse getStatus(String mobileNumber);
}
