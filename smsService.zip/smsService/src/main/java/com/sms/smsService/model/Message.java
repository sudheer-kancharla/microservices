package com.sms.smsService.model;

import java.io.Serializable;
import java.util.List;

public class Message implements Serializable {

	private String message;
	private List<String> mobileNumber;

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<String> getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(List<String> mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
}
