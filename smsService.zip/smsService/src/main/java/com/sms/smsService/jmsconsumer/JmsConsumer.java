package com.sms.smsService.jmsconsumer;

import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.sms.smsService.model.Message;

@Component
@EnableJms
public class JmsConsumer {

	@JmsListener(destination = "send-sms-queue")
	public void smsSendListener(Message message) {
		System.out.println("Sending sms ");
	}
}
