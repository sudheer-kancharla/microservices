package com.sms.smsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
