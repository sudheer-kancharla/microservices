package com.sms.accountService.dao;

import com.sms.accountService.model.UserProfile;

public interface AccountDao {

	public boolean login(UserProfile userProfile);
	public String signUp(UserProfile userProfile);
}
