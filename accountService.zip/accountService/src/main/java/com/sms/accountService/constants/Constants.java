package com.sms.accountService.constants;

public class Constants {
	public static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	public static final int AUTH_TOKEN_LENGTH = 12;
}
