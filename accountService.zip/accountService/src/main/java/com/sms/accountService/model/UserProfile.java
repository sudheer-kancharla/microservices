package com.sms.accountService.model;

public class UserProfile {

	private String userName;
	private String password;

	public UserProfile(String string, String string2) {
		this.userName = userName;
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String toString() {
		return "[userName: " + userName + ", passowrd: " + password + "]";
	}
}
