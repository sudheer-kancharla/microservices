package com.sms.accountService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sms.accountService.constants.Constants;
import com.sms.accountService.dao.AccountDao;
import com.sms.accountService.model.UserProfile;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao accountDao;
	
	@Override
	public String login(UserProfile userProfile) {
		return accountDao.login(userProfile) ? generateAuthToken(Constants.AUTH_TOKEN_LENGTH) : "Login failed - User not exists ";
	}

	private String generateAuthToken(int count) {
		StringBuilder builder = new StringBuilder();
		while (count >= 0) {
			builder.append(Constants.ALPHA_NUMERIC_STRING.charAt((int) (Math.random() * count)));
			count--;
		}
		return builder.toString();
	}

	@Override
	public String signUp(UserProfile userProfile) {
		
		return accountDao.signUp(userProfile);
	}

}
