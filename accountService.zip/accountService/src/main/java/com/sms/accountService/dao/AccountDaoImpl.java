package com.sms.accountService.dao;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Repository;

import com.sms.accountService.model.UserProfile;

@Repository
public class AccountDaoImpl implements AccountDao {

	private static ConcurrentHashMap<String, UserProfile> DB = new ConcurrentHashMap<String, UserProfile>();

	static {
		DB.put("sudheer", new UserProfile("sudheer", "1234"));
		DB.put("siva", new UserProfile("siva", "5678"));
	}
	@Override
	public boolean login(UserProfile userProfile) {
		if(DB.containsKey(userProfile.getUserName())) {
			UserProfile user = DB.get(userProfile.getUserName());
			return userProfile.getPassword().equals(user.getPassword()) ? true : false;
		} else {
			return false;
		}
	}

	@Override
	public String signUp(UserProfile userProfile) {
		String response = "";
		if (DB.containsKey(userProfile.getUserName())) {
			response = "User already exist with userName : " + userProfile.getUserName();
		} else {
			DB.put(userProfile.getUserName(), userProfile);
			response = userProfile.getUserName() + " registed successfully.";
		}
		return response;
	}

}
