package com.sms.accountService.service;

import com.sms.accountService.model.UserProfile;

public interface AccountService {

	public String login(UserProfile userProfile);
	public String signUp(UserProfile userProfile);
}
