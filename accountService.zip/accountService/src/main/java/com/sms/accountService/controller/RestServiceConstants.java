package com.sms.accountService.controller;

public class RestServiceConstants {

	public static final String LOGIN_API = "/login";
	public static final String SIGNUP_API = "/singup";
}
